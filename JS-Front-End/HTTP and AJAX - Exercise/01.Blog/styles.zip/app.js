function attachEvents() {
    const baseUrl = "http://localhost:3030/jsonstore/blog";
    const loadPostsButton = document.getElementById("btnLoadPosts");
    const postsSelect = document.getElementById("posts");
    const postTitle = document.getElementById("post-title");
    const postBody = document.getElementById("post-body");
    const postComments = document.getElementById("post-comments");

    const clearPostDetails = () => {
        postTitle.textContent = "Post Details";
        postBody.textContent = "";
        postComments.innerHTML = "";
    };

    const fetchPosts = async () => {
        try {
            const response = await fetch(`${baseUrl}/posts`);
            const data = await response.json();

            clearPostDetails();

            for (const { id, title } of Object.values(data)) {
                const option = document.createElement("option");
                option.value = id;
                option.textContent = title;
                postsSelect.appendChild(option);
            }
        } catch (error) {
            console.error("Error loading posts:", error);
        }
    };

    const fetchPostDetails = async (postId) => {
        try {
            const response = await fetch(`${baseUrl}/posts/${postId}`);
            const post = await response.json();

            postTitle.textContent = post.title;
            postBody.textContent = post.body;
        } catch (error) {
            console.error("Error loading post details:", error);
        }
    };

    const fetchComments = async (postId) => {
        try {
            const response = await fetch(`${baseUrl}/comments`);
            const data = await response.json();

            for (const { postId: commentPostId, text } of Object.values(data)) {
                if (commentPostId === postId) {
                    const commentItem = document.createElement("li");
                    commentItem.textContent = text;
                    postComments.appendChild(commentItem);
                }
            }
        } catch (error) {
            console.error("Error loading comments:", error);
        }
    };

    loadPostsButton.addEventListener("click", fetchPosts);

    const viewPosts = document.getElementById("btnViewPost");
    viewPosts.addEventListener("click", () => {
        const selectedPostId = postsSelect.value;

        clearPostDetails();
        fetchPostDetails(selectedPostId);
        fetchComments(selectedPostId);
    });
}

attachEvents();
