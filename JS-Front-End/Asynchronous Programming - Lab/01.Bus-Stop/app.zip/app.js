function getInfo() {
    const baseUrl = "http://localhost:3030/jsonstore/bus/businfo/";
    const button = document.getElementById("submit");
    const textBox = document.getElementById("stopId");
    const nameContainer = document.getElementById("stopName");
    const busesInfoContainer = document.getElementById("buses");

    button.addEventListener("click", (e) => {
        e.preventDefault();

        nameContainer.textContent = "";
        busesInfoContainer.innerHTML = "";

        fetchData(baseUrl + textBox.value)
            .then(data => {
                nameContainer.textContent = data.name;

                for (const [busNumber, time] of Object.entries(data.buses)) {
                    let li = document.createElement("li");
                    li.textContent = `Bus ${busNumber} arrives in ${time} minutes`
                    busesInfoContainer.appendChild(li);
                }                    
            })
            .catch(() =>{
                nameContainer.textContent = "Error";
            });
    })
}

function fetchData(url){
    return new Promise((resolve, reject)=>{
        fetch(url)
            .then(response=>{
                if(!response.ok){
                    return;
                }

                return response.json();
            })
            .then(data => resolve(data))
            .catch(error => reject(error));
    });
}